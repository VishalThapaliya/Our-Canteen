﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using bal = esigelec_bal;

namespace esigelec_work
{
    public partial class menuitemlist : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["catid"] != null)
                {
                    bal.Recipes obj = new bal.Recipes();
                    DataList1.DataSource = obj.getbycategory(Int32.Parse(Request.QueryString["catid"].ToString()));
                    DataList1.DataBind();
                }
            }
        }
    }
}